package noteapp.jc.com.quicknotes;


import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentA extends Fragment {

    public static SQLiteDatabase  db ;
    //public static ArrayList<String> title_notes = new ArrayList<String>();
    public CustomListAdapter adapter;
    public static List<CustomList> mylist;
    public static ListView listView;

    public FragmentA() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_a, container, false);
        db = getContext().openOrCreateDatabase("mydatabase", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS memo(id INTEGER PRIMARY KEY AUTOINCREMENT,title VARCHAR,notes VARCHAR);");
        listView = view.findViewById(R.id.list);
        mylist = new ArrayList<CustomList>();
        mylist.clear();//clears the array


        /*Cursor cursor = db.rawQuery("SELECT * FROM memo", null);
        final int index = cursor.getColumnIndex("title");
        cursor.moveToFirst();
        if (cursor != null && (cursor.getCount() > 0)) {
            do {
                title_notes.add(String.valueOf(cursor.getString(index)));
            } while (cursor.moveToNext());
        }
        cursor.close();*/


        populateList();


        adapter = new CustomListAdapter(getContext(), mylist);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                showMemo(i+1);

            }
        });



        return view;
    }
    public static void populateList()
    {
        Cursor cursor = db.rawQuery("SELECT * FROM memo", null);
        final int index = cursor.getColumnIndex("title");
        final int index1 = cursor.getColumnIndex("notes");
        cursor.moveToFirst();
        if (cursor != null && (cursor.getCount() > 0)) {
            do {
                mylist.add(new CustomList(String.valueOf(cursor.getString(index)),String.valueOf(cursor.getString(index1))));
            } while (cursor.moveToNext());
        }
        cursor.close();
    }
    public void showMemo(int j)
    {
        Cursor c = db.rawQuery("SELECT * FROM memo WHERE id = " + j,null);
        int idget = c.getColumnIndex("id");
        int titleget = c.getColumnIndex("title");
        int contentget = c.getColumnIndex("notes");
        c.moveToFirst();
        int valid = c.getInt(idget);
        String a = String.valueOf(c.getString(titleget));
        String b = String.valueOf(c.getString(contentget));
        Intent intent1 = new Intent(getContext(),Entry.class);
        intent1.putExtra("titleval",a);
        intent1.putExtra("noteval",b);
        intent1.putExtra("idvalue",valid);
        startActivity(intent1);


    }
    public static void updateMemo(String ntitle,String nname,int idv)
    {
        String tryup = "UPDATE memo SET title = '" + ntitle + "'," + " notes = '" + nname + "' WHERE id = " + idv + ";";
        db.execSQL(tryup);

    }

}
