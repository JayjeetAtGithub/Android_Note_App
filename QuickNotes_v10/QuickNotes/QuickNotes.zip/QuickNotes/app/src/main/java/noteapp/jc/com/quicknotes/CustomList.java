package noteapp.jc.com.quicknotes;

/**
 * Created by Jayjeet Chakraborty on 08-12-2017.
 */

public class CustomList {

    String titleStore,noteStore;

    public CustomList(String titleStore, String noteStore) {
        this.titleStore = titleStore;
        this.noteStore = noteStore;
    }

    public String getTitleStore() {
        return titleStore;
    }

    public void setTitleStore(String titleStore) {
        this.titleStore = titleStore;
    }

    public String getNoteStore() {
        return noteStore;
    }

    public void setNoteStore(String noteStore) {
        this.noteStore = noteStore;
    }
}
