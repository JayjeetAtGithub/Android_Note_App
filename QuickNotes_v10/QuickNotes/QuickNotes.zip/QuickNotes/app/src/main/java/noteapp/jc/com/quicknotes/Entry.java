package noteapp.jc.com.quicknotes;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Entry extends AppCompatActivity {
    public static EditText title, notes;
    FloatingActionButton b,u;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entry);

        title = (EditText) findViewById(R.id.editText);
        notes = (EditText) findViewById(R.id.editText2);

        b = (FloatingActionButton) findViewById(R.id.floatingActionButton);
        u = (FloatingActionButton)findViewById(R.id.floatingActionButton2);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String titlev = title.getText().toString();
                String notesv = notes.getText().toString();
                addRecord(titlev,notesv);

            }
        });
        u.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uTitle = title.getText().toString();
                String uNotes = notes.getText().toString();
                int idput = getIntent().getExtras().getInt("idvalue");
                FragmentA.updateMemo(uTitle,uNotes,idput);
                Toast.makeText(Entry.this, "Memo Updated", Toast.LENGTH_SHORT).show();


            }
        });

        String recTitle = getIntent().getStringExtra("titleval");
        String recnote = getIntent().getStringExtra("noteval");
        title.setText(recTitle);
        notes.setText(recnote);

    }

    @Override
    public void onBackPressed() {
        Intent intent2 = new Intent(this,MainActivity.class);
        startActivity(intent2);
        FragmentA.mylist.clear();
        FragmentA.populateList();

    }

    public void addRecord(String title1, String notes1) {

        String sql = "INSERT INTO memo (title,notes) VALUES ('" + title1 + "','" + notes1 + "');";
        FragmentA.db.execSQL(sql);
        Toast.makeText(this, "Memo Saved Successfully", Toast.LENGTH_LONG).show();

    }

}
